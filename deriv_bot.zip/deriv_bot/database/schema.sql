CREATE DATABASE deriv_mpesa_bot;
USE deriv_mpesa_bot;

CREATE TABLE users
(
    id INT
    AUTO_INCREMENT PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    phone_number VARCHAR
    (20) NOT NULL,
    deriv_token TEXT NULL,
    status ENUM
    ('active', 'suspended') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON
    UPDATE CURRENT_TIMESTAMP
    );

    CREATE TABLE transactions
    (
        id INT
        AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM
        ('deposit', 'withdrawal') NOT NULL,
    amount DECIMAL
        (15,2) NOT NULL,
    fee DECIMAL
        (15,2) NOT NULL,
    mpesa_reference VARCHAR
        (100) NULL,
    deriv_reference VARCHAR
        (100) NULL,
    status ENUM
        ('pending', 'pending_payment', 'processing', 'completed', 'failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON
        UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY
        (user_id) REFERENCES users
        (id)
);

        CREATE TABLE admin_settings
        (
            id INT
            AUTO_INCREMENT PRIMARY KEY,
    setting_name VARCHAR
            (50) UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON
            UPDATE CURRENT_TIMESTAMP
            );

            INSERT INTO admin_settings
                (setting_name, setting_value)
            VALUES
                ('deposit_rate', '0.02'),
                ('withdrawal_rate', '0.03'),
                ('min_deposit', '100'),
                ('max_deposit', '50000'),
                ('min_withdrawal', '200'),
                ('max_withdrawal', '100000'),
                ('maintenance_mode', 'false');

            CREATE INDEX idx_transactions_user_id ON transactions(user_id);
            CREATE INDEX idx_transactions_status ON transactions(status);
            CREATE INDEX idx_transactions_created_at ON transactions(created_at);
<?php
class TelegramService
{
    private $bot_token;
    private $api_url;

    public function __construct()
    {
        $this->bot_token = Config::TELEGRAM_BOT_TOKEN;
        $this->api_url = "https://api.telegram.org/bot{$this->bot_token}/";
    }

    public function sendMessage($chat_id, $text, $reply_markup = null)
    {
        $data = [
            'chat_id' => $chat_id,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];

        if ($reply_markup) {
            $data['reply_markup'] = json_encode($reply_markup);
        }

        return $this->makeRequest('sendMessage', $data);
    }

    public function editMessage($chat_id, $message_id, $text, $reply_markup = null)
    {
        $data = [
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => $text,
            'parse_mode' => 'HTML'
        ];

        if ($reply_markup) {
            $data['reply_markup'] = json_encode($reply_markup);
        }

        return $this->makeRequest('editMessageText', $data);
    }

    private function makeRequest($method, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->api_url . $method);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }

    public function setWebhook()
    {
        $data = ['url' => Config::WEBHOOK_URL];
        return $this->makeRequest('setWebhook', $data);
    }
}

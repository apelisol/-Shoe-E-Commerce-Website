<?php
class MPesaService
{
    private $consumer_key;
    private $consumer_secret;
    private $business_shortcode;
    private $passkey;
    private $callback_url;
    private $access_token;

    public function __construct()
    {
        $this->consumer_key = Config::MPESA_CONSUMER_KEY;
        $this->consumer_secret = Config::MPESA_CONSUMER_SECRET;
        $this->business_shortcode = Config::MPESA_BUSINESS_SHORTCODE;
        $this->passkey = Config::MPESA_PASSKEY;
        $this->callback_url = Config::MPESA_CALLBACK_URL;
        $this->access_token = $this->generateAccessToken();
    }

    private function generateAccessToken()
    {
        $credentials = base64_encode($this->consumer_key . ':' . $this->consumer_secret);
        $url = 'https://sandbox-api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Authorization: Basic ' . $credentials]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return $result['access_token'] ?? null;
    }

    public function stkPush($phone_number, $amount, $account_reference, $transaction_desc)
    {
        $timestamp = date('YmdHis');
        $password = base64_encode($this->business_shortcode . $this->passkey . $timestamp);

        $request = [
            'BusinessShortCode' => $this->business_shortcode,
            'Password' => $password,
            'Timestamp' => $timestamp,
            'TransactionType' => 'CustomerPayBillOnline',
            'Amount' => $amount,
            'PartyA' => $phone_number,
            'PartyB' => $this->business_shortcode,
            'PhoneNumber' => $phone_number,
            'CallBackURL' => $this->callback_url,
            'AccountReference' => $account_reference,
            'TransactionDesc' => $transaction_desc
        ];

        $url = 'https://sandbox-api.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->access_token,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }

    public function b2cPayment($phone_number, $amount, $remarks)
    {
        $request = [
            'InitiatorName' => 'testapi',
            'SecurityCredential' => $this->generateSecurityCredential(),
            'CommandID' => 'BusinessPayment',
            'Amount' => $amount,
            'PartyA' => $this->business_shortcode,
            'PartyB' => $phone_number,
            'Remarks' => $remarks,
            'QueueTimeOutURL' => $this->callback_url,
            'ResultURL' => $this->callback_url,
            'Occasion' => 'Deriv Withdrawal'
        ];

        $url = 'https://sandbox-api.safaricom.co.ke/mpesa/b2c/v1/paymentrequest';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->access_token,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }

    private function generateSecurityCredential()
    {
        // You need to implement this based on Safaricom's security credential generation
        // This involves encrypting the initiator password with Safaricom's public key
        return 'your_security_credential';
    }

    public function queryTransactionStatus($checkout_request_id)
    {
        $timestamp = date('YmdHis');
        $password = base64_encode($this->business_shortcode . $this->passkey . $timestamp);

        $request = [
            'BusinessShortCode' => $this->business_shortcode,
            'Password' => $password,
            'Timestamp' => $timestamp,
            'CheckoutRequestID' => $checkout_request_id
        ];

        $url = 'https://sandbox-api.safaricom.co.ke/mpesa/stkpushquery/v1/query';

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $this->access_token,
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($ch);
        curl_close($ch);

        return json_decode($response, true);
    }
}

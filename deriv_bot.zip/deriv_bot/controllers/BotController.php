<?php
class BotController
{
    private $telegram;
    private $user_model;
    private $transaction_model;
    private $deriv_service;
    private $mpesa_service;
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();

        $this->telegram = new TelegramService();
        $this->user_model = new User($this->db);
        $this->transaction_model = new Transaction($this->db);
        $this->deriv_service = new DerivService();
        $this->mpesa_service = new MPesaService();
    }

    public function handleUpdate($update)
    {
        if (isset($update['message'])) {
            $this->handleMessage($update['message']);
        } elseif (isset($update['callback_query'])) {
            $this->handleCallback($update['callback_query']);
        }
    }

    private function handleMessage($message)
    {
        $chat_id = $message['chat']['id'];
        $text = $message['text'] ?? '';
        $user_id = $message['from']['id'];

        $user = $this->user_model->getByTelegramId($user_id);

        switch ($text) {
            case '/start':
                $this->sendWelcomeMessage($chat_id, $user);
                break;
            case '/deposit':
                $this->initiateDeposit($chat_id, $user);
                break;
            case '/withdraw':
                $this->initiateWithdrawal($chat_id, $user);
                break;
            case '/balance':
                $this->showBalance($chat_id, $user);
                break;
            case '/history':
                $this->showTransactionHistory($chat_id, $user);
                break;
            case '/rates':
                $this->showRates($chat_id);
                break;
            default:
                if (!$user) {
                    $this->requestRegistration($chat_id);
                } else {
                    $this->handleUserInput($chat_id, $text, $user);
                }
                break;
        }
    }

    private function sendWelcomeMessage($chat_id, $user)
    {
        if (!$user) {
            $text = "🎉 <b>Welcome to Stepash Bot!</b>\n\n";
            $text .= "This bot helps you deposit and withdraw funds from your Deriv account using M-Pesa.\n\n";
            $text .= "To get started, please share your phone number for registration.";

            $keyboard = [
                'keyboard' => [
                    [['text' => '📱 Share Phone Number', 'request_contact' => true]]
                ],
                'resize_keyboard' => true,
                'one_time_keyboard' => true
            ];

            $this->telegram->sendMessage($chat_id, $text, $keyboard);
        } else {
            $this->showMainMenu($chat_id);
        }
    }

    private function showMainMenu($chat_id)
    {
        $text = "🏠 <b>Main Menu</b>\n\n";
        $text .= "Choose an option below:";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '💰 Deposit', 'callback_data' => 'deposit'],
                    ['text' => '💸 Withdraw', 'callback_data' => 'withdraw']
                ],
                [
                    ['text' => '💳 Balance', 'callback_data' => 'balance'],
                    ['text' => '📊 History', 'callback_data' => 'history']
                ],
                [
                    ['text' => '📋 Rates', 'callback_data' => 'rates'],
                    ['text' => '⚙️ Settings', 'callback_data' => 'settings']
                ]
            ]
        ];

        $this->telegram->sendMessage($chat_id, $text, $keyboard);
    }

    private function initiateDeposit($chat_id, $user)
    {
        if (!$user) {
            $this->requestRegistration($chat_id);
            return;
        }

        $text = "💰 <b>Deposit to Deriv</b>\n\n";
        $text .= "Current Rates:\n";
        $text .= "• Deposit Fee: " . (Config::DEPOSIT_RATE * 100) . "%\n";
        $text .= "• Min Amount: KES " . number_format(Config::MIN_DEPOSIT) . "\n";
        $text .= "• Max Amount: KES " . number_format(Config::MAX_DEPOSIT) . "\n\n";
        $text .= "Please enter the amount you want to deposit (in KES):";

        $this->telegram->sendMessage($chat_id, $text);
        $this->setUserState($user['id'], 'waiting_deposit_amount');
    }

    private function initiateWithdrawal($chat_id, $user)
    {
        if (!$user) {
            $this->requestRegistration($chat_id);
            return;
        }

        // Check Deriv balance first
        $balance_response = $this->deriv_service->getBalance($user['deriv_token']);

        if (!$balance_response['success']) {
            $text = "❌ Unable to fetch your Deriv balance. Please check your account connection.";
            $this->telegram->sendMessage($chat_id, $text);
            return;
        }

        $balance = $balance_response['data']['balance'] ?? 0;

        $text = "💸 <b>Withdraw from Deriv</b>\n\n";
        $text .= "Available Balance: $" . number_format($balance, 2) . "\n\n";
        $text .= "Current Rates:\n";
        $text .= "• Withdrawal Fee: " . (Config::WITHDRAWAL_RATE * 100) . "%\n";
        $text .= "• Min Amount: KES " . number_format(Config::MIN_WITHDRAWAL) . "\n";
        $text .= "• Max Amount: KES " . number_format(Config::MAX_WITHDRAWAL) . "\n\n";
        $text .= "Please enter the amount you want to withdraw (in KES):";

        $this->telegram->sendMessage($chat_id, $text);
        $this->setUserState($user['id'], 'waiting_withdrawal_amount');
    }

    private function processDeposit($chat_id, $amount, $user)
    {
        // Validate amount
        if ($amount < Config::MIN_DEPOSIT || $amount > Config::MAX_DEPOSIT) {
            $text = "❌ Invalid amount. Please enter between KES " .
                number_format(Config::MIN_DEPOSIT) . " and KES " .
                number_format(Config::MAX_DEPOSIT);
            $this->telegram->sendMessage($chat_id, $text);
            return;
        }

        $fee = $amount * Config::DEPOSIT_RATE;
        $total_amount = $amount + $fee;

        // Create transaction record
        $transaction_id = $this->transaction_model->create(
            $user['id'],
            'deposit',
            $amount,
            $fee
        );

        // Initiate M-Pesa STK Push
        $mpesa_response = $this->mpesa_service->stkPush(
            $user['phone_number'],
            $total_amount,
            "DERIV" . $transaction_id,
            "Deriv Account Deposit"
        );

        if ($mpesa_response['ResponseCode'] == '0') {
            $text = "📱 <b>Payment Request Sent!</b>\n\n";
            $text .= "Amount: KES " . number_format($amount) . "\n";
            $text .= "Fee: KES " . number_format($fee) . "\n";
            $text .= "Total: KES " . number_format($total_amount) . "\n\n";
            $text .= "Please check your phone and enter your M-Pesa PIN to complete the payment.";

            $this->telegram->sendMessage($chat_id, $text);

            // Update transaction with M-Pesa reference
            $this->transaction_model->updateStatus(
                $transaction_id,
                'pending_payment',
                $mpesa_response['CheckoutRequestID']
            );
        } else {
            $text = "❌ Failed to initiate payment. Please try again later.";
            $this->telegram->sendMessage($chat_id, $text);

            $this->transaction_model->updateStatus($transaction_id, 'failed');
        }

        $this->clearUserState($user['id']);
    }

    private function processWithdrawal($chat_id, $amount, $user)
    {
        // Validate amount
        if ($amount < Config::MIN_WITHDRAWAL || $amount > Config::MAX_WITHDRAWAL) {
            $text = "❌ Invalid amount. Please enter between KES " .
                number_format(Config::MIN_WITHDRAWAL) . " and KES " .
                number_format(Config::MAX_WITHDRAWAL);
            $this->telegram->sendMessage($chat_id, $text);
            return;
        }

        $fee = $amount * Config::WITHDRAWAL_RATE;
        $net_amount = $amount - $fee;

        // Check Deriv balance
        $balance_response = $this->deriv_service->getBalance($user['deriv_token']);
        if (!$balance_response['success'] || $balance_response['data']['balance'] < $amount) {
            $text = "❌ Insufficient balance in your Deriv account.";
            $this->telegram->sendMessage($chat_id, $text);
            return;
        }

        // Create transaction record
        $transaction_id = $this->transaction_model->create(
            $user['id'],
            'withdrawal',
            $amount,
            $fee
        );

        // Initiate Deriv withdrawal
        $deriv_response = $this->deriv_service->withdraw($user['deriv_token'], $amount);

        if ($deriv_response['success']) {
            // Send M-Pesa payment
            $mpesa_response = $this->mpesa_service->b2cPayment(
                $user['phone_number'],
                $net_amount,
                "Deriv Withdrawal - Transaction #" . $transaction_id
            );

            if ($mpesa_response['ResponseCode'] == '0') {
                $text = "✅ <b>Withdrawal Processing!</b>\n\n";
                $text .= "Amount: KES " . number_format($amount) . "\n";
                $text .= "Fee: KES " . number_format($fee) . "\n";
                $text .= "You'll receive: KES " . number_format($net_amount) . "\n\n";
                $text .= "Funds will be sent to your M-Pesa shortly.";

                $this->telegram->sendMessage($chat_id, $text);

                $this->transaction_model->updateStatus($transaction_id, 'processing');
            } else {
                $text = "❌ Failed to process withdrawal. Please contact support.";
                $this->telegram->sendMessage($chat_id, $text);

                $this->transaction_model->updateStatus($transaction_id, 'failed');
            }
        } else {
            $text = "❌ Failed to withdraw from Deriv account. Please try again later.";
            $this->telegram->sendMessage($chat_id, $text);

            $this->transaction_model->updateStatus($transaction_id, 'failed');
        }

        $this->clearUserState($user['id']);
    }

    private function showRates($chat_id)
    {
        $text = "📋 <b>Current Rates & Limits</b>\n\n";
        $text .= "<b>Deposits:</b>\n";
        $text .= "• Fee: " . (Config::DEPOSIT_RATE * 100) . "%\n";
        $text .= "• Minimum: KES " . number_format(Config::MIN_DEPOSIT) . "\n";
        $text .= "• Maximum: KES " . number_format(Config::MAX_DEPOSIT) . "\n\n";

        $text .= "<b>Withdrawals:</b>\n";
        $text .= "• Fee: " . (Config::WITHDRAWAL_RATE * 100) . "%\n";
        $text .= "• Minimum: KES " . number_format(Config::MIN_WITHDRAWAL) . "\n";
        $text .= "• Maximum: KES " . number_format(Config::MAX_WITHDRAWAL) . "\n\n";

        $text .= "<i>Rates are subject to change. All transactions are processed securely.</i>";

        $this->telegram->sendMessage($chat_id, $text);
    }

    private function showTransactionHistory($chat_id, $user)
    {
        if (!$user) {
            $this->requestRegistration($chat_id);
            return;
        }

        $transactions = $this->transaction_model->getUserTransactions($user['id']);

        if (empty($transactions)) {
            $text = "📊 <b>Transaction History</b>\n\n";
            $text .= "No transactions found. Start by making your first deposit!";
            $this->telegram->sendMessage($chat_id, $text);
            return;
        }

        $text = "📊 <b>Recent Transactions</b>\n\n";

        foreach ($transactions as $transaction) {
            $status_emoji = $this->getStatusEmoji($transaction['status']);
            $type_emoji = $transaction['type'] == 'deposit' ? '💰' : '💸';

            $text .= "{$type_emoji} {$status_emoji} <b>" . ucfirst($transaction['type']) . "</b>\n";
            $text .= "Amount: KES " . number_format($transaction['amount']) . "\n";
            $text .= "Fee: KES " . number_format($transaction['fee']) . "\n";
            $text .= "Status: " . ucfirst($transaction['status']) . "\n";
            $text .= "Date: " . date('M j, Y H:i', strtotime($transaction['created_at'])) . "\n";

            if ($transaction['mpesa_reference']) {
                $text .= "M-Pesa Ref: " . $transaction['mpesa_reference'] . "\n";
            }

            $text .= "────────────────────\n";
        }

        $this->telegram->sendMessage($chat_id, $text);
    }

    private function getStatusEmoji($status)
    {
        switch ($status) {
            case 'completed':
                return '✅';
            case 'pending':
                return '⏳';
            case 'failed':
                return '❌';
            case 'processing':
                return '🔄';
            default:
                return '⚪';
        }
    }

    private function showBalance($chat_id, $user)
    {
        if (!$user) {
            $this->requestRegistration($chat_id);
            return;
        }

        if (!$user['deriv_token']) {
            $text = "❌ Your Deriv account is not connected. Please use /settings to link your account.";
            $this->telegram->sendMessage($chat_id, $text);
            return;
        }

        $balance_response = $this->deriv_service->getBalance($user['deriv_token']);

        if ($balance_response['success']) {
            $balance = $balance_response['data']['balance'] ?? 0;
            $currency = $balance_response['data']['currency'] ?? 'USD';

            $text = "💳 <b>Account Balance</b>\n\n";
            $text .= "Available Balance: {$currency} " . number_format($balance, 2) . "\n\n";
            $text .= "Ready to trade or withdraw? Use the menu below.";

            $keyboard = [
                'inline_keyboard' => [
                    [
                        ['text' => '💰 Deposit More', 'callback_data' => 'deposit'],
                        ['text' => '💸 Withdraw', 'callback_data' => 'withdraw']
                    ]
                ]
            ];

            $this->telegram->sendMessage($chat_id, $text, $keyboard);
        } else {
            $text = "❌ Unable to fetch balance. Please check your account connection.";
            $this->telegram->sendMessage($chat_id, $text);
        }
    }

    private function handleCallback($callback_query)
    {
        $chat_id = $callback_query['message']['chat']['id'];
        $data = $callback_query['data'];
        $user_id = $callback_query['from']['id'];

        $user = $this->user_model->getByTelegramId($user_id);

        switch ($data) {
            case 'deposit':
                $this->initiateDeposit($chat_id, $user);
                break;
            case 'withdraw':
                $this->initiateWithdrawal($chat_id, $user);
                break;
            case 'balance':
                $this->showBalance($chat_id, $user);
                break;
            case 'history':
                $this->showTransactionHistory($chat_id, $user);
                break;
            case 'rates':
                $this->showRates($chat_id);
                break;
            case 'settings':
                $this->showSettings($chat_id, $user);
                break;
        }
    }

    private function handleUserInput($chat_id, $text, $user)
    {
        $user_state = $this->getUserState($user['id']);

        switch ($user_state) {
            case 'waiting_deposit_amount':
                $amount = floatval($text);
                if ($amount > 0) {
                    $this->processDeposit($chat_id, $amount, $user);
                } else {
                    $this->telegram->sendMessage($chat_id, "❌ Please enter a valid amount.");
                }
                break;

            case 'waiting_withdrawal_amount':
                $amount = floatval($text);
                if ($amount > 0) {
                    $this->processWithdrawal($chat_id, $amount, $user);
                } else {
                    $this->telegram->sendMessage($chat_id, "❌ Please enter a valid amount.");
                }
                break;

            case 'waiting_deriv_token':
                $this->linkDerivAccount($chat_id, $text, $user);
                break;

            default:
                $this->showMainMenu($chat_id);
                break;
        }
    }

    private function requestRegistration($chat_id)
    {
        $text = "📱 <b>Registration Required</b>\n\n";
        $text .= "Please share your phone number to register and start using the bot.";

        $keyboard = [
            'keyboard' => [
                [['text' => '📱 Share Phone Number', 'request_contact' => true]]
            ],
            'resize_keyboard' => true,
            'one_time_keyboard' => true
        ];

        $this->telegram->sendMessage($chat_id, $text, $keyboard);
    }

    private function showSettings($chat_id, $user)
    {
        if (!$user) {
            $this->requestRegistration($chat_id);
            return;
        }

        $deriv_status = $user['deriv_token'] ? '✅ Connected' : '❌ Not Connected';

        $text = "⚙️ <b>Settings</b>\n\n";
        $text .= "Phone: " . $user['phone_number'] . "\n";
        $text .= "Deriv Account: " . $deriv_status . "\n\n";

        $keyboard = [
            'inline_keyboard' => [
                [['text' => '🔗 Link Deriv Account', 'callback_data' => 'link_deriv']],
                [['text' => '🔄 Update Phone', 'callback_data' => 'update_phone']],
                [['text' => '🏠 Main Menu', 'callback_data' => 'main_menu']]
            ]
        ];

        $this->telegram->sendMessage($chat_id, $text, $keyboard);
    }

    private function linkDerivAccount($chat_id, $token, $user)
    {
        // Validate Deriv token
        $auth_response = $this->deriv_service->authenticateUser($token);

        if ($auth_response['success']) {
            $this->user_model->updateDerivToken($user['id'], $token);

            $text = "✅ <b>Deriv Account Connected!</b>\n\n";
            $text .= "Your account has been successfully linked. You can now deposit and withdraw funds.";

            $this->telegram->sendMessage($chat_id, $text);
            $this->clearUserState($user['id']);
            $this->showMainMenu($chat_id);
        } else {
            $text = "❌ Invalid token. Please check your Deriv API token and try again.";
            $this->telegram->sendMessage($chat_id, $text);
        }
    }

    private function setUserState($user_id, $state)
    {
        // Store user state in session or database
        $_SESSION['user_states'][$user_id] = $state;
    }

    private function getUserState($user_id)
    {
        return $_SESSION['user_states'][$user_id] ?? null;
    }

    private function clearUserState($user_id)
    {
        unset($_SESSION['user_states'][$user_id]);
    }
}

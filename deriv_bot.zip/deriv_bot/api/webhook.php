<?php
session_start();
require_once '../config/database.php';
require_once '../config/config.php';
require_once '../models/User.php';
require_once '../models/Transaction.php';
require_once '../services/DerivService.php';
require_once '../services/MPesaService.php';
require_once '../services/TelegramService.php';
require_once '../controllers/BotController.php';

// Verify webhook
$webhook_secret = hash_hmac('sha256', file_get_contents('php://input'), Config::API_KEY);
$telegram_signature = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';

if (!hash_equals($webhook_secret, $telegram_signature)) {
    http_response_code(403);
    exit('Unauthorized');
}

$input = json_decode(file_get_contents('php://input'), true);

if ($input) {
    $bot = new BotController();
    $bot->handleUpdate($input);
}

http_response_code(200);
echo 'OK';

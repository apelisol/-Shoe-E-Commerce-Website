<?php
require_once '../config/database.php';
require_once '../config/config.php';
require_once '../models/Transaction.php';
require_once '../services/TelegramService.php';
require_once '../services/DerivService.php';

$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    exit('Bad Request');
}

$database = new Database();
$db = $database->getConnection();
$transaction_model = new Transaction($db);
$telegram = new TelegramService();
$deriv_service = new DerivService();

// Handle STK Push callback
if (isset($input['Body']['stkCallback'])) {
    $callback = $input['Body']['stkCallback'];
    $result_code = $callback['ResultCode'];
    $checkout_request_id = $callback['CheckoutRequestID'];

    // Find transaction by checkout request ID
    $query = "SELECT t.*, u.telegram_id, u.deriv_token 
              FROM transactions t 
              JOIN users u ON t.user_id = u.id 
              WHERE t.mpesa_reference = :checkout_id LIMIT 1";

    $stmt = $db->prepare($query);
    $stmt->bindParam(':checkout_id', $checkout_request_id);
    $stmt->execute();
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($transaction) {
        if ($result_code == 0) {
            // Payment successful
            $mpesa_receipt = '';
            if (isset($callback['CallbackMetadata']['Item'])) {
                foreach ($callback['CallbackMetadata']['Item'] as $item) {
                    if ($item['Name'] == 'MpesaReceiptNumber') {
                        $mpesa_receipt = $item['Value'];
                        break;
                    }
                }
            }

            // Process deposit to Deriv
            $deriv_response = $deriv_service->deposit(
                $transaction['deriv_token'],
                $transaction['amount']
            );

            if ($deriv_response['success']) {
                $transaction_model->updateStatus($transaction['id'], 'completed', $mpesa_receipt);

                $message = "✅ <b>Deposit Successful!</b>\n\n";
                $message .= "Amount: KES " . number_format($transaction['amount']) . "\n";
                $message .= "M-Pesa Receipt: " . $mpesa_receipt . "\n";
                $message .= "Your Deriv account has been credited.";
            } else {
                $transaction_model->updateStatus($transaction['id'], 'failed');

                $message = "❌ <b>Deposit Failed</b>\n\n";
                $message .= "Payment received but failed to credit Deriv account. Please contact support.\n";
                $message .= "Reference: " . $mpesa_receipt;
            }

            $telegram->sendMessage($transaction['telegram_id'], $message);
        } else {
            // Payment failed
            $transaction_model->updateStatus($transaction['id'], 'failed');

            $message = "❌ <b>Payment Failed</b>\n\n";
            $message .= "Your M-Pesa payment was not successful. Please try again.";

            $telegram->sendMessage($transaction['telegram_id'], $message);
        }
    }
}

// Handle B2C callback (withdrawals)
if (isset($input['Result'])) {
    $result = $input['Result'];
    $result_code = $result['ResultCode'];
    $conversation_id = $result['ConversationID'];

    // Find transaction by conversation ID or other reference
    $query = "SELECT t.*, u.telegram_id 
              FROM transactions t 
              JOIN users u ON t.user_id = u.id 
              WHERE t.mpesa_reference = :conversation_id LIMIT 1";

    $stmt = $db->prepare($query);
    $stmt->bindParam(':conversation_id', $conversation_id);
    $stmt->execute();
    $transaction = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($transaction) {
        if ($result_code == 0) {
            // Withdrawal successful
            $transaction_model->updateStatus($transaction['id'], 'completed');

            $net_amount = $transaction['amount'] - $transaction['fee'];
            $message = "✅ <b>Withdrawal Successful!</b>\n\n";
            $message .= "Amount sent: KES " . number_format($net_amount) . "\n";
            $message .= "Check your M-Pesa messages for confirmation.";
        } else {
            // Withdrawal failed
            $transaction_model->updateStatus($transaction['id'], 'failed');

            $message = "❌ <b>Withdrawal Failed</b>\n\n";
            $message .= "We couldn't send money to your M-Pesa. Please contact support.";
        }

        $telegram->sendMessage($transaction['telegram_id'], $message);
    }
}

http_response_code(200);
echo json_encode(['ResultCode' => 0, 'ResultDesc' => 'Success']);

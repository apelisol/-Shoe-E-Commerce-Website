<?php
header('Content-Type: application/json');
require_once '../config/database.php';
require_once '../config/config.php';
require_once '../models/User.php';
require_once '../models/Transaction.php';
require_once '../services/DerivService.php';
require_once '../services/MPesaService.php';

class AppAPI
{
    private $db;
    private $user_model;
    private $transaction_model;
    private $deriv_service;
    private $mpesa_service;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
        $this->user_model = new User($this->db);
        $this->transaction_model = new Transaction($this->db);
        $this->deriv_service = new DerivService();
        $this->mpesa_service = new MPesaService();
    }

    public function handleRequest()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
        $path = trim($path, '/');
        $segments = explode('/', $path);

        // API Authentication
        $api_key = $_SERVER['HTTP_X_API_KEY'] ?? '';
        if ($api_key !== Config::API_KEY) {
            $this->sendResponse(['error' => 'Unauthorized'], 401);
            return;
        }

        switch ($method) {
            case 'POST':
                $this->handlePost($segments);
                break;
            case 'GET':
                $this->handleGet($segments);
                break;
            default:
                $this->sendResponse(['error' => 'Method not allowed'], 405);
        }
    }

    private function handlePost($segments)
    {
        $data = json_decode(file_get_contents('php://input'), true);

        switch ($segments[2] ?? '') {
            case 'register':
                $this->register($data);
                break;
            case 'deposit':
                $this->initiateDeposit($data);
                break;
            case 'withdraw':
                $this->initiateWithdrawal($data);
                break;
            case 'link-deriv':
                $this->linkDerivAccount($data);
                break;
            default:
                $this->sendResponse(['error' => 'Endpoint not found'], 404);
        }
    }

    private function handleGet($segments)
    {
        switch ($segments[2] ?? '') {
            case 'balance':
                $this->getBalance($_GET['user_id'] ?? '');
                break;
            case 'transactions':
                $this->getTransactions($_GET['user_id'] ?? '');
                break;
            case 'rates':
                $this->getRates();
                break;
            default:
                $this->sendResponse(['error' => 'Endpoint not found'], 404);
        }
    }

    private function register($data)
    {
        $phone = $data['phone_number'] ?? '';
        $telegram_id = $data['telegram_id'] ?? '';

        if (empty($phone) || empty($telegram_id)) {
            $this->sendResponse(['error' => 'Phone number and Telegram ID required'], 400);
            return;
        }

        $user_id = $this->user_model->create($telegram_id, $phone);

        if ($user_id) {
            $this->sendResponse(['success' => true, 'user_id' => $user_id]);
        } else {
            $this->sendResponse(['error' => 'Registration failed'], 500);
        }
    }

    private function initiateDeposit($data)
    {
        $user_id = $data['user_id'] ?? '';
        $amount = floatval($data['amount'] ?? 0);

        if (empty($user_id) || $amount <= 0) {
            $this->sendResponse(['error' => 'Invalid parameters'], 400);
            return;
        }

        $user = $this->user_model->getByTelegramId($user_id);
        if (!$user) {
            $this->sendResponse(['error' => 'User not found'], 404);
            return;
        }

        if ($amount < Config::MIN_DEPOSIT || $amount > Config::MAX_DEPOSIT) {
            $this->sendResponse([
                'error' => 'Amount out of range',
                'min' => Config::MIN_DEPOSIT,
                'max' => Config::MAX_DEPOSIT
            ], 400);
            return;
        }

        $fee = $amount * Config::DEPOSIT_RATE;
        $total = $amount + $fee;

        $transaction_id = $this->transaction_model->create($user['id'], 'deposit', $amount, $fee);

        $mpesa_response = $this->mpesa_service->stkPush(
            $user['phone_number'],
            $total,
            "DERIV" . $transaction_id,
            "Deriv Deposit"
        );

        if ($mpesa_response['ResponseCode'] == '0') {
            $this->transaction_model->updateStatus(
                $transaction_id,
                'pending_payment',
                $mpesa_response['CheckoutRequestID']
            );

            $this->sendResponse([
                'success' => true,
                'transaction_id' => $transaction_id,
                'checkout_request_id' => $mpesa_response['CheckoutRequestID'],
                'amount' => $amount,
                'fee' => $fee,
                'total' => $total
            ]);
        } else {
            $this->sendResponse(['error' => 'Payment initiation failed'], 500);
        }
    }

    private function getRates()
    {
        $this->sendResponse([
            'deposit' => [
                'rate' => Config::DEPOSIT_RATE,
                'min_amount' => Config::MIN_DEPOSIT,
                'max_amount' => Config::MAX_DEPOSIT
            ],
            'withdrawal' => [
                'rate' => Config::WITHDRAWAL_RATE,
                'min_amount' => Config::MIN_WITHDRAWAL,
                'max_amount' => Config::MAX_WITHDRAWAL
            ]
        ]);
    }

    private function sendResponse($data, $status = 200)
    {
        http_response_code($status);
        echo json_encode($data);
        exit;
    }
}

// Initialize API
$api = new AppAPI();
$api->handleRequest();

<?php
session_start();
require_once '../config/database.php';

// Simple admin authentication (enhance this for production)
if (!isset($_SESSION['admin_logged_in'])) {
    if ($_POST['admin_password'] ?? '' === 'your_admin_password') {
        $_SESSION['admin_logged_in'] = true;
    } else {
        // Show login form
?>
        <!DOCTYPE html>
        <html>

        <head>
            <title>Admin Login</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    background: #f0f0f0;
                }

                .login-form {
                    background: white;
                    padding: 2rem;
                    border-radius: 8px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }

                input {
                    width: 100%;
                    padding: 0.5rem;
                    margin: 0.5rem 0;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }

                button {
                    background: #007bff;
                    color: white;
                    padding: 0.5rem 1rem;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }
            </style>
        </head>

        <body>
            <form method="POST" class="login-form">
                <h2>Admin Login</h2>
                <input type="password" name="admin_password" placeholder="Admin Password" required>
                <button type="submit">Login</button>
            </form>
        </body>

        </html>
<?php
        exit;
    }
}

$database = new Database();
$db = $database->getConnection();

// Get statistics
$stats_query = "SELECT 
    COUNT(*) as total_users,
    (SELECT COUNT(*) FROM transactions WHERE status = 'completed' AND type = 'deposit') as completed_deposits,
    (SELECT COUNT(*) FROM transactions WHERE status = 'completed' AND type = 'withdrawal') as completed_withdrawals,
    (SELECT SUM(amount) FROM transactions WHERE status = 'completed' AND type = 'deposit') as total_deposit_volume,
    (SELECT SUM(amount) FROM transactions WHERE status = 'completed' AND type = 'withdrawal') as total_withdrawal_volume,
    (SELECT SUM(fee) FROM transactions WHERE status = 'completed') as total_fees
    FROM users";

$stats = $db->query($stats_query)->fetch(PDO::FETCH_ASSOC);

// Get recent transactions
$recent_query = "SELECT t.*, u.phone_number 
                FROM transactions t 
                JOIN users u ON t.user_id = u.id 
                ORDER BY t.created_at DESC 
                LIMIT 20";
$recent_transactions = $db->query($recent_query)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Deriv M-Pesa Bot - Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-value {
            font-size: 2em;
            font-weight: bold;
            color: #007bff;
        }

        table {
            width: 100%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        th {
            background: #f8f9fa;
        }

        .status-completed {
            color: #28a745;
        }

        .status-pending {
            color: #ffc107;
        }

        .status-failed {
            color: #dc3545;
        }

        .logout {
            float: right;
            background: #dc3545;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <h1>Deriv M-Pesa Bot Admin Dashboard</h1>
            <a href="?logout=1" class="logout">Logout</a>
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-value"><?= number_format($stats['total_users']) ?></div>
                <div>Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= number_format($stats['completed_deposits']) ?></div>
                <div>Completed Deposits</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?= number_format($stats['completed_withdrawals']) ?></div>
                <div>Completed Withdrawals</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">KES <?= number_format($stats['total_deposit_volume'] ?? 0) ?></div>
                <div>Deposit Volume</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">KES <?= number_format($stats['total_withdrawal_volume'] ?? 0) ?></div>
                <div>Withdrawal Volume</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">KES <?= number_format($stats['total_fees'] ?? 0) ?></div>
                <div>Total Fees Earned</div>
            </div>
        </div>

        <div style="background: white; padding: 20px; border-radius: 8px;">
            <h2>Recent Transactions</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Phone</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Fee</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_transactions as $transaction): ?>
                        <tr>
                            <td>#<?= $transaction['id'] ?></td>
                            <td><?= substr($transaction['phone_number'], 0, 7) ?>***</td>
                            <td><?= ucfirst($transaction['type']) ?></td>
                            <td>KES <?= number_format($transaction['amount']) ?></td>
                            <td>KES <?= number_format($transaction['fee']) ?></td>
                            <td class="status-<?= $transaction['status'] ?>"><?= ucfirst($transaction['status']) ?></td>
                            <td><?= date('M j, H:i', strtotime($transaction['created_at'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
/deriv-mpesa-bot
├── /admin
│ └── dashboard.php
├── /api
│ ├── app_api.php
│ ├── mpesa_callback.php
│ └── webhook.php
├── /config
│ ├── config.php
│ └── database.php
├── /controllers
│ └── BotController.php
├── /models
│ ├── Transaction.php
│ └── User.php
├── /services
│ ├── DerivService.php
│ ├── MPesaService.php
│ └── TelegramService.php
└── /database
└── schema.sql
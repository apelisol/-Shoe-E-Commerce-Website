<?php
class User
{
    private $conn;
    private $table_name = "users";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function create($telegram_id, $phone_number, $deriv_token = null)
    {
        $query = "INSERT INTO " . $this->table_name . " 
                  (telegram_id, phone_number, deriv_token, created_at) 
                  VALUES (:telegram_id, :phone_number, :deriv_token, NOW())";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':telegram_id', $telegram_id);
        $stmt->bindParam(':phone_number', $phone_number);
        $stmt->bindParam(':deriv_token', $deriv_token);

        return $stmt->execute();
    }

    public function getByTelegramId($telegram_id)
    {
        $query = "SELECT * FROM " . $this->table_name . " WHERE telegram_id = :telegram_id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':telegram_id', $telegram_id);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateDerivToken($user_id, $deriv_token)
    {
        $query = "UPDATE " . $this->table_name . " SET deriv_token = :deriv_token WHERE id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':deriv_token', $deriv_token);
        $stmt->bindParam(':user_id', $user_id);

        return $stmt->execute();
    }
}

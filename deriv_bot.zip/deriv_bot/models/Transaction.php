<?php
class Transaction
{
    private $conn;
    private $table_name = "transactions";

    public function __construct($db)
    {
        $this->conn = $db;
    }

    public function create($user_id, $type, $amount, $fee, $mpesa_ref = null, $deriv_ref = null, $status = 'pending')
    {
        $query = "INSERT INTO " . $this->table_name . " 
                  (user_id, type, amount, fee, mpesa_reference, deriv_reference, status, created_at) 
                  VALUES (:user_id, :type, :amount, :fee, :mpesa_ref, :deriv_ref, :status, NOW())";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':type', $type);
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':fee', $fee);
        $stmt->bindParam(':mpesa_ref', $mpesa_ref);
        $stmt->bindParam(':deriv_ref', $deriv_ref);
        $stmt->bindParam(':status', $status);

        $stmt->execute();
        return $this->conn->lastInsertId();
    }

    public function updateStatus($transaction_id, $status, $reference = null)
    {
        $query = "UPDATE " . $this->table_name . " 
                  SET status = :status, updated_at = NOW()";

        if ($reference) {
            $query .= ", mpesa_reference = :reference";
        }

        $query .= " WHERE id = :transaction_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':transaction_id', $transaction_id);

        if ($reference) {
            $stmt->bindParam(':reference', $reference);
        }

        return $stmt->execute();
    }

    public function getUserTransactions($user_id, $limit = 10)
    {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE user_id = :user_id 
                  ORDER BY created_at DESC 
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

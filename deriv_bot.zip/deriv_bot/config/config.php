<?php
class Config
{
    // Deriv API Configuration
    const DERIV_APP_ID = 'your_deriv_app_id'; // Your provided app ID
    const DERIV_API_URL = 'wss://ws.derivws.com/websockets/v3?app_id=' . self::DERIV_APP_ID;

    // M-Pesa Daraja API Configuration
    const MPESA_CONSUMER_KEY = 'your_mpesa_consumer_key';
    const MPESA_CONSUMER_SECRET = 'your_mpesa_consumer_secret';
    const MPESA_BUSINESS_SHORTCODE = 'your_business_shortcode';
    const MPESA_PASSKEY = 'your_mpesa_passkey';
    const MPESA_CALLBACK_URL = 'https://yourdomain.com/api/mpesa_callback.php';

    // Bot Configuration
    const TELEGRAM_BOT_TOKEN = 'your_telegram_bot_token';
    const WEBHOOK_URL = 'https://yourdomain.com/api/webhook.php';

    // Rate Configuration (customizable)
    const DEPOSIT_RATE = 0.02; // 2% fee on deposits
    const WITHDRAWAL_RATE = 0.03; // 3% fee on withdrawals
    const MIN_DEPOSIT = 100; // Minimum deposit in KES
    const MAX_DEPOSIT = 50000; // Maximum deposit in KES
    const MIN_WITHDRAWAL = 200; // Minimum withdrawal in KES
    const MAX_WITHDRAWAL = 100000; // Maximum withdrawal in KES

    // Security
    const JWT_SECRET = 'your_jwt_secret_key';
    const API_KEY = 'your_api_key';
}
